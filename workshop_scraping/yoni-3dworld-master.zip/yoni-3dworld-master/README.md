# yoni-3dworld

npm run install
npm start