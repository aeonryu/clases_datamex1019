import initGlobe from './globe';
import './style.css';

initGlobe(document.getElementById('globe-app'));